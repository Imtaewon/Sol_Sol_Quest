# SolQuest React Native Web 서버 배포 가이드

## 개요
React Native Web으로 빌드된 SolQuest 앱을 서버에 배포하는 방법입니다.

## 파일 구성
- `dist/` - 빌드된 정적 파일들
- `nginx-config.txt` - Nginx 설정 파일
- `deploy.sh` - 자동 배포 스크립트

## 배포 방법

### 방법 1: 자동 배포 (권장)
```bash
# 1. 파일들을 서버에 업로드
# 2. 스크립트 실행 권한 부여
chmod +x deploy.sh

# 3. 배포 스크립트 실행
sudo ./deploy.sh
```

### 방법 2: 수동 배포
```bash
# 1. 웹 디렉토리 생성
sudo mkdir -p /var/www/solquest-web

# 2. 파일 복사
sudo cp -r dist/* /var/www/solquest-web/

# 3. 권한 설정
sudo chown -R www-data:www-data /var/www/solquest-web
sudo chmod -R 755 /var/www/solquest-web

# 4. Nginx 설정
sudo cp nginx-config.txt /etc/nginx/sites-available/solquest
sudo ln -sf /etc/nginx/sites-available/solquest /etc/nginx/sites-enabled/

# 5. Nginx 재시작
sudo nginx -t
sudo systemctl reload nginx
```

## 접속 확인
- 웹 브라우저: http://15.165.185.135
- 모바일 브라우저: http://15.165.185.135

## 주요 특징
1. **모바일 앱처럼 보임**: 웹에서 모바일 앱처럼 표시
2. **API 연동**: 기존 FastAPI 백엔드와 연동
3. **PWA 지원**: 홈 화면에 앱 아이콘 추가 가능
4. **반응형**: 다양한 화면 크기 지원

## 문제 해결

### Nginx 오류 시
```bash
# 설정 테스트
sudo nginx -t

# 로그 확인
sudo tail -f /var/log/nginx/error.log
```

### 권한 문제 시
```bash
# 권한 재설정
sudo chown -R www-data:www-data /var/www/solquest-web
sudo chmod -R 755 /var/www/solquest-web
```

### 백업 복원
```bash
# 백업에서 복원
sudo cp -r /var/www/solquest-web.backup.* /var/www/solquest-web
sudo systemctl reload nginx
```

## 연락처
문제 발생 시 개발팀에 문의해주세요.
