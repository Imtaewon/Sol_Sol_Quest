#!/bin/bash

# SolQuest React Native Web 배포 스크립트
# 서버 관리자가 실행할 스크립트

echo "=== SolQuest React Native Web 배포 시작 ==="

# 1. 웹 디렉토리 생성
echo "1. 웹 디렉토리 생성 중..."
sudo mkdir -p /var/www/solquest-web

# 2. 기존 파일 백업 (있는 경우)
if [ -d "/var/www/solquest-web" ] && [ "$(ls -A /var/www/solquest-web)" ]; then
    echo "2. 기존 파일 백업 중..."
    sudo cp -r /var/www/solquest-web /var/www/solquest-web.backup.$(date +%Y%m%d_%H%M%S)
fi

# 3. 새로운 파일 복사
echo "3. 새로운 파일 복사 중..."
sudo cp -r dist/* /var/www/solquest-web/

# 4. 권한 설정
echo "4. 권한 설정 중..."
sudo chown -R www-data:www-data /var/www/solquest-web
sudo chmod -R 755 /var/www/solquest-web

# 5. Nginx 설정 파일 복사
echo "5. Nginx 설정 파일 복사 중..."
sudo cp nginx-config.txt /etc/nginx/sites-available/solquest

# 6. 기존 설정 비활성화 (있는 경우)
if [ -L "/etc/nginx/sites-enabled/default" ]; then
    echo "6. 기존 설정 비활성화 중..."
    sudo rm /etc/nginx/sites-enabled/default
fi

# 7. 새 설정 활성화
echo "7. 새 설정 활성화 중..."
sudo ln -sf /etc/nginx/sites-available/solquest /etc/nginx/sites-enabled/

# 8. Nginx 설정 테스트
echo "8. Nginx 설정 테스트 중..."
sudo nginx -t

if [ $? -eq 0 ]; then
    echo "9. Nginx 재시작 중..."
    sudo systemctl reload nginx
    echo "✅ 배포 완료!"
    echo "🌐 접속 URL: http://15.165.185.135"
    echo "📱 모바일에서도 접속 가능합니다."
else
    echo "❌ Nginx 설정 오류가 있습니다."
    echo "nginx-config.txt 파일을 확인해주세요."
    exit 1
fi

echo "=== 배포 완료 ==="
